<script>
  import { onMount, onDestroy } from 'svelte';

	import LoremIpsum from './LoremIpsum.svelte'

	import Introduction from './Introduction.svelte'

  let activeStepIndex = 0;
  let observer;
  let scrollyRef;
  let flourishID = "2299512"; // L'ID de la story Flourish

// le texte des boites
	
  let stepsData = [
    { "text": "Suite � la crise du Covid-19, <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>l'ann�e 2021</strong></mark> est marqu�e par l<mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>explosion des prix</strong></mark> principalement dans le <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>secteur de l'�nergie</strong></mark>qui repr�sente les deux tiers de linflation totale cette ann�e-l�. Linflation a grimp� de 1,2% en janvier � 5,3% en d�cembre pour lUE et de 0,9% � 5% pour la zone euro. "},
    { "text": "<mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>En 2022</strong></mark>, l<mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>inflation continue d'augmenter</strong></mark>et atteint 11,5% en octobre pour lUE et 10,6% pour la zone euro, des niveaux in�dits depuis le d�but de leuro. Cette ann�e-l�, ce sont principalement les prix des <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>denr�es alimentaires</strong></mark> qui explosent en raison du d�but de la guerre en Ukraine." },
    { "text": "En d�cembre <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>2023</strong></mark>, l'inflation totale atteint 3,4% pour l'UE et 2,9% pour la zone euro, revenant � des <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>niveaux similaires � ceux du 2�me trimestre 2021</strong></mark>. Cette baisse de l'inflation totale est due � la <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>diminution des prix de l'�nergie</strong></mark>. Dans d'autres cat�gories de produits, l'inflation a grimp� � des niveaux historiquement �lev�s." },
		{ "text": "Depuis 2021, l'inflation totale en Europe a continu� d'augmenter jusqu'en octobre 2022, atteignant des taux record. � partir d'octobre 2022, l'inflation a commenc� � diminuer progressivement, mais n'a pas encore retrouv� son <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>niveau initial</strong></mark>, qui �tait de <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>0,4%</strong></mark>pour <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>l'UE</strong></mark>l'UE et de <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>0,2%</strong></mark>0,2% pour la <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>zone euro</strong></mark>en ao�t 2020." },
		{ "text": "En <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>2024</strong></mark>, selon la Commission europ�enne, la <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>fin des mesures de soutien � l'�nergie</strong></mark> et les <mark style='background-color: #8F8BCE; color:white; padding: 2px; border-radius: 5px;'><strong>perturbations des flux commerciaux en mer Rouge</strong></mark> devraient l�g�rement augmenter les prix, mais n'arr�teront pas la baisse de l'inflation. En f�vrier 2024, l'inflation est de 2,8% pour l'UE et 2,6% pour la zone euro." },
  ];

	// Le "moteur" du scrollytelling qui utilise l'Intersection Observer API (en gros, le code observe ce qu'il y a � l'�cran)
	// �a on ne touche pas sinon tout se casse !

  onMount(() => {
    observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const { target, isIntersecting } = entry;
        const index = Array.from(scrollyRef.querySelectorAll('.step')).indexOf(target);
        if (isIntersecting) {
          activeStepIndex = index;
        }
      });
    }, { threshold: 0.6 });

    const stepElements = scrollyRef.querySelectorAll('.step');
    stepElements.forEach(el => observer.observe(el));
  });

  onDestroy(() => {
    observer.disconnect();
  });
</script>

<h1>Linflation en Europe en baisse durant lann�e 2023</h1>

<Introduction/>

<!-- si tu affiches la step_0, alors montre la slide_0 -->
<!-- si tu affiches la step_1, alors montre la slide_1 -->
<!-- si tu affiches la step_2, alors montre la slide_2 -->

<section bind:this={scrollyRef} class="section-container">

	  <div class="foreground">
    {#each stepsData as { text }, index}
      <div class="step" data-step={index}>
        <div class="step-content">
          <p>{@html text}</p> <!-- @html important pour que le css du script soit pris en compte-->
        </div>
      </div>
    {/each}
  </div>
	
  <div class="sticky-background">
    <!-- On affiche la slide Flourish en fonction de l'index -->
		<iframe src={`https://flo.uri.sh/story/${flourishID}/embed#slide-${activeStepIndex}`} title="Contenu interactif ou visuel" class="flourish-embed" frameborder="0" scrolling="no" style="width:100%;height:100vh;"></iframe>
  </div>


</section>


<style>

	/* Ici les valeurs pour l'ensemble de la page > 
	peut n�cessiter des modifs de couleurs dans Flourish 
	pour s'assurer que le graphe soit tjs bien visible (titre de graphique noir sur
	fond de page noir,�a ne se voit pas bien...*/

	:global(body) {
    background-color: #EEEEFF; 
		color: black;
		font-family: 'Montserrat', sans-serif; 
  }
	
	*{
		box-sizing: border-box;
	}
	.section-container {
    margin-top: 1em;
    text-align: center;
    display: flex;
    flex-direction: row; 
		
  }

  .sticky-background {
    position: sticky;
    top: 0;
    height: 100vh;
    flex: 0 1 60%;
    overflow: hidden;
    z-index: 1;
  }

  .foreground {
    display: flex;
    flex-direction: column;
    align-items: center;
    flex: 0 1 40%;
		margin-bottom: 100vh;
  }

  .step {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
    position: relative;
    z-index: 2;
    width: 100%;
  }

  .step-content {
    background-color: rgba(245, 245, 245, 0.8);
		box-shadow: 1px 1px 10px rgba(0, 0, 0, 0.2);
    color: black;
    border-radius: 10px;
		border: 5px solid #DFDDFF;
    padding: 0.5rem 1rem;
    display: flex;
    flex-direction: column;
    justify-content: center;
    z-index: 10;
    font-size: 1rem;
    text-align: left;
    width: 100%; 
    max-width: 500px; 
    margin: auto;
  }

	/* Pour adapter la vue en mobile: steps centr�es par dessus le graphique */

  @media screen and (max-width: 768px) {
    .section-container {
      flex-direction: column-reverse;
    }
    .sticky-background, .foreground {
      width: 100%; 
    }
    .foreground {
      margin-top: -80vh; 
    }
  }
</style>

